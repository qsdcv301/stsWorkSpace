package net.taehyeon.kdtcom.dao;

import java.util.List;

import net.taehyeon.kdtcom.dto.MemberDto;

public interface MemberDao {
	List<MemberDto> getAllMembers();
	MemberDto getMember(int num);
	void createMember(MemberDto dto);
	void updateMember(MemberDto dto);
	void delMember(int num);

}
