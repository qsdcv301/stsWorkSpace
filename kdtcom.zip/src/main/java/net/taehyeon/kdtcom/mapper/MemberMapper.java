package net.taehyeon.kdtcom.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import net.taehyeon.kdtcom.dto.MemberDto;

@Mapper
public interface MemberMapper {
	MemberDto selectMem();

	List<MemberDto> listMem();

	void insertMem(MemberDto dto);

	void updateMem(MemberDto dto);

	void deleteMem(int num);
}
