package net.taehyeon.kdtcom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.taehyeon.kdtcom.dao.MemberDao;
import net.taehyeon.kdtcom.dto.MemberDto;
import net.taehyeon.kdtcom.mapper.MemberMapper;

@Service
public class MemberDaoImpl implements MemberDao {

	@Autowired
	private MemberMapper memberMapper;

	@Override
	public List<MemberDto> getAllMembers() {
		return memberMapper.listMem();
	}

	@Override
	public MemberDto getMember(int num) {
		return memberMapper.selectMem();
	}

	@Override
	public void createMember(MemberDto dto) {
		memberMapper.insertMem(dto);
	}

	@Override
	public void updateMember(MemberDto dto) {
		memberMapper.updateMem(dto);
	}

	@Override
	public void delMember(int num) {
		memberMapper.deleteMem(num);
	}


}
